var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
var modal = document.getElementById('id02');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
let cartItems = [];

function addToCart(itemName, price) {
  cartItems.push({ name: itemName, price: price });
  updateCart();
}

function updateCart() {
  const cartList = document.getElementById('cart-items');
  cartList.innerHTML = '';

  let totalPrice = 0;

  for (let i = 0; i < cartItems.length; i++) {
    const item = cartItems[i];

    const listItem = document.createElement('li');
    listItem.innerHTML = `${item.name} - $${item.price}`;
    cartList.appendChild(listItem);

    totalPrice += item.price;
  }

  const checkoutButton = document.getElementById('checkout');
  checkoutButton.innerHTML = `Checkout - Total: $${totalPrice.toFixed(2)}`;
}

function checkout() {
    // Simulating order processing
    setTimeout(function() {
      alert('Thank you for your order! proceed for payment');
      cartItems = [];
      updateCart();
    }, 2000); // 2-second delay to simulate order processing
    document.getElementById("payment-form").addEventListener("submit", function(event) {
      event.preventDefault(); // Prevent form submission
    
      // Retrieve form inputs
      var cardNumber = document.getElementById("card-number").value;
      var expirationDate = document.getElementById("expiration-date").value;
      var cvv = document.getElementById("cvv").value;
    
      // Perform validation
      if (cardNumber.length !== 16) {
        alert("Invalid card number");
        return;
      }
    
      if (expirationDate.length !== 4 || isNaN(expirationDate)) {
        alert("Invalid expiration date");
        return;
      }
    
      if (cvv.length !== 3 || isNaN(cvv)) {
        alert("Invalid CVV");
        return;
      }
    
      // Payment successful, perform further processing here
      alert("Payment successful!");
    
      // Reset form
      document.getElementById("payment-form").reset();
    });
 }
 
 
